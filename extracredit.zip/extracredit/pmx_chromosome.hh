/*
 * Extension of the Chromosome class (see chromosome.hh). Implements
 * STUFFSTUFF STUFF STUFF STUFF STUFF STUFF  
 */

#pragma once

#include <random>
#include "cities.hh"
#include "chromosome.hh"

class PMX_Chromosome: public Chromosome {
 public:
  // Creation method for new Chromsomoe. Saves a copy of the cities and
  // generates a completely random permutation from a list of cities.
  using Chromosome::Chromosome;

  // Polymorphic creation method from an existing Chromosome.
  // This method allocates memory for the newly created chromosome.
  // It is the caller's responsibility to free this memory.
  PMX_Chromosome* clone() const {
    PMX_Chromosome* retval = new PMX_Chromosome(cities_ptr_);
    retval->order_ = order_;
    return retval;
  }
  // Return a pair of offsprings by recombining with another chromosome
  // Note: this method allocates memory for the new offsprings
  // It is the caller's responsibility to free this memory.
  std::pair<PMX_Chromosome*, PMX_Chromosome*> recombine(const PMX_Chromosome*
                                                                      other);
 protected:
  // Much like its predecessor Chromosome, this somewhat changed utility
  // function is protected.
  // For an ordered set of parents, return a child using the ordered crossover.
  // The child will have the same values as p1 in the range [begin,end),
  // and all the other values in the same order as in p2.
  virtual PMX_Chromosome*
  create_crossover_child(const PMX_Chromosome* parent1,
                         const PMX_Chromosome* parent2,
                         unsigned begin,
                         unsigned end) const;


};
