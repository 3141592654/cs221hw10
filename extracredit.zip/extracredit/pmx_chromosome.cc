/*
 * Implementation for PMX_Chromosome class
 */

#include <algorithm>
#include <cassert>
#include "pmx_chromosome.hh"

//////////////////////////////////////////////////////////////////////////////
// Return a pair of offsprings by recombining with another chromosome
// Note: this method allocates memory for the new offsprings
// No major changes from chromosome.cc
std::pair<PMX_Chromosome*, PMX_Chromosome*>
PMX_Chromosome::recombine(const PMX_Chromosome* other) {
  assert(is_valid());
  assert(other->is_valid());

  // Assert that the other chromosome points to the same cities as this one
  // does, because if it doesn't bad stuff is going to happen.
  assert(other->compare_cities_ptr(cities_ptr_));

  // need to include size() because create_crossover_child takes [b, e):
  // note that it is order_.size()-1. see github commit "bug with order()"
  std::uniform_int_distribution<int> dist(0, order_.size()-1);

  // Pick two random indices such that b <= e:
  auto r1 = dist(generator_);
  auto r2 = dist(generator_);
  auto[b, e] = std::minmax(r1, r2);

  // Make children:
  PMX_Chromosome* child1 = create_crossover_child(this, other, b, e);
  PMX_Chromosome* child2 = create_crossover_child(other, this, b, e);

  return std::make_pair(child1, child2);
}

// Significant changes from chromosome.cc
PMX_Chromosome* PMX_Chromosome::create_crossover_child(const PMX_Chromosome* p1, const PMX_Chromosome* p2, unsigned b, unsigned e) const {

  const unsigned len = p1->order_.size();
  assert(len == p2->order_.size());
  PMX_Chromosome* child = p2->clone();

  // apply the permutation to p2
  for (unsigned i = b; i < e; i++) {
    unsigned thing_from_p1 = p1->order_[i];
    for (unsigned j = 0; j < len; j++) {
      if (j == b) {
        if (i != b) {
          j=i-1;
        }
        continue;
      }
      if (child->order_[j] == thing_from_p1) {
        std::swap(child->order_[i],child->order_[j]);
        j=len;
      }
    }
  }

  assert(child->is_valid());
  return child;
}

